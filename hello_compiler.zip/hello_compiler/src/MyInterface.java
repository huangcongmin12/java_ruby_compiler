
public interface MyInterface {

 public void sayHello();
}
